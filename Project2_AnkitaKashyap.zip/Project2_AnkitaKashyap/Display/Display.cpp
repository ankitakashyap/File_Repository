/////////////////////////////////////////////////////////////////////////////
// Display.cpp - Responsible for displaying the results of XML Document    //
// ver 1.0                                                                                                   //
//Language:    Visual C++ 11, Visual Studio 2013                                        //                       
// Platform:    MAC OSX,Core i5, Windows 7                                         //
// Application: Spring, 2015 : XML Document Model                          //
// Author:      Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu                           //
/////////////////////////////////////////////////////////////////////////////

#include "Display.h"
#include <Windows.h>

using namespace XmlProcessing;

//--------------<constructor for display>----------------

Display::Display(XmlDocument& ds) : store1(ds)
{

}


//--------------<display elements based on the tag>----------------

void Display::displayElements(std::vector<sPtr> e, std::string title)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 6 for elements";
	cout << endl << std::string(80, '/') << std::endl << endl;
	if (e.size() <= 0)
	{
		cout << "Elements with specified tag  " << title << " are not found"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	else
	{
		cout << "Elements with specified tag are as follows: " << title << endl;
		cout << endl << std::string(80, '-') << std::endl;

		for (int i = 0; i < e.size(); i++)
		{
			cout << e[i]->toString() << endl;
		}
	
	}
	cout << endl;
}

//--------------<display Children based on the tag>----------------

void Display::displayChildren(std::vector<sPtr> e, std::string tag, std::string tag1)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 8 for children by ID";
	cout << endl << std::string(80, '/') << std::endl << endl;

	if (e.size() > 0)
	{
		cout << "Elements with tag are as follows: " << tag << endl;
		cout << "Elements with children are follows: " << tag1 << endl;

		cout << endl << std::string(80, '-') << std::endl; 

		for (int i = 0; i < e.size(); i++)
		{
			cout << e[i]->toString() << endl;
		}

	}

	else
	{
		cout << "Elements with specified tag: " << tag << "and children:" << tag1 << " are not found" << endl;

		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
	
}

//--------------<display element based on the tag>----------------

void Display::displayElement(std::vector<sPtr> e, std::string title)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 6 for element";
	cout << endl << std::string(80, '/') << std::endl << endl;
	if (e.size() > 0)
	{
		cout << "Element with tag is as follows: " << title << endl;
		cout << endl << std::string(80, '-') << std::endl;

		for (int i = 0; i < e.size(); i++)
		{
			cout << e[i]->toString() << endl;
		}
	}
	else
	{
		cout << "Element with tag " << title << " is not found" << endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
}



//--------------<displaying  Add Child element>----------------

void Display::displayAddChildren(bool check, std::string parent, std::string child)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 7 for Add Child";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The children to be added is as follows: " << child << endl;
	cout << "The Parent of the Children is as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;

	if (check)
	{
		cout << "The children have been added successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;
		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not be added successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;
	}
	cout << endl;

}

//--------------<display Add Child Based on the  ID >----------------

void Display::displayAddChildren_ID(bool check, std::string parent, std::string child)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 7 for Add Child based on ID";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The children to be added are as follows : " << child << endl;
	cout << "The  Id of the Parent to which the Children should be added are as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;


	if (check)
	{
		cout << "The children have been added successfully by Id"<<endl;
		cout << endl << std::string(80, '-') << std::endl;
		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not be added successfully by Id"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;

}

//--------------<display Remove Child element>----------------

void Display::displayRemoveChildren(bool check, std::string parent, std::string child)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 7 for Remove Child";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The children to be removed are as follows: " << child << endl;
	cout << "The Parent of the Children is as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;

	if (check)
	{
		cout << "The children have been removed successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

		sPtr elements = store1.docElementReturn();
		cout << elements->toString();
	}
	else
	{
		cout << "Could not remove successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;

}

//--------------<display the descendents based on the tag>----------------

void Display::displayDescendents(std::vector<sPtr> e, std::string tag, std::string tag1)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 8 for displaying descendents ";
	cout << endl << std::string(80, '/') << std::endl << endl;

	if (e.size() <= 0)
	{
		cout << "Elements with tag: " << tag << "and children:" << tag1 << "  are not found" << endl;

		cout << endl << std::string(80, '-') << std::endl;

	}
	else
	{
		cout << "Elements with tag are as follows: " << tag << endl;
		cout << "Elements with descendents are as follows: " << tag1 << endl;

		cout << endl << std::string(80, '-') << std::endl;

		for (int i = 0; i < e.size(); i++)
		{
			cout << e[i]->toString() << endl;
		}
	}
	cout << endl;
}

//--------------<displays the element based on the ID>----------------

void Display::displayElement_ID(std::vector<sPtr> e, std::string id)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 5 for display of element by ID";
	cout << endl << std::string(80, '/') << std::endl << endl;

	if (e.size() > 0)
	{
		cout << "Elements with id are as follows: " << id << endl;
		cout << endl << std::string(80, '-') << std::endl;

		for (int i = 0; i < e.size(); i++)
		{
			cout << e[i]->toString() << endl;
		}

	}
	else
	{
		cout << "Elements with id " << id << " are not found" << endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
}



//--------------<display Remove Child by Id element>----------------

void Display::displayRemoveChildren_ID(bool check, std::string parent, std::string child)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 7 for Remove Child based on ID";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The children to be removed are as follows: " << child << endl;
	cout << "The  Id of the Parent from which the Children should be removed are as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;

	if (check)
	{
		cout << "The children have been removed successfully";
		cout << endl << std::string(80, '-') << std::endl;

		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not be removed successfully";
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;

}


//--------------<display fetch Attributes based on the tag>----------------

void Display::displayFetchedAttributes(std::vector<std::pair<std::string, std::string>> attr, std::string parent)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 8 for obtaining Attributes by Tag";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The Attributes of the tag to be obtained are as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;

	if (attr.size() > 0)
	{
		cout << "The Attributes have been obtained successfully" << endl;
		cout << endl << std::string(80, '-') << std::endl;

		for (int i = 0; i < attr.size(); i++)
		{
			cout << attr[i].first << "=" << attr[i].second << endl;
		}
		
	}
	else
	{
		cout << "No attributes obtained";
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
}

//--------------<display add Attributes based on the tag>----------------


void Display:: displayAddAttribute(bool check, std::string parent, std::string key, std::string value)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 9 for displaying Add Attributes";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The Attributes to be added are as follows: " << key << "=" <<value << endl;
	cout << "The Tag to which it should be added is as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;


	if (check)
	{
		cout << "The Attributes have been added successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not add the attributes successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
}

//--------------<display Remove Attributes for a tag>----------------


void Display:: displayRemoveAttribute(bool check, std::string parent, std::string value)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 9 for displaying Remove Attribute";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The name of the Attribute to be removed is as follows: " << value << endl;
	cout << "The Tag from which it should be removed is as follows: " << parent << endl;
	cout << endl << std::string(80, '-') << std::endl;


	if (check)
	{
		cout << "The Attributes have been removed successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;

		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not remove the attributes successfully"<<endl;
		cout << endl << std::string(80, '-') << std::endl;
	}
	cout << endl;
}


//--------------<display Add Root element to the empty tree>----------------

void Display::displayAddRoot(bool save, std::string root)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 7 for Adding Root to Empty Tree";
	cout << endl << std::string(80, '/') << std::endl << endl;

	cout << "The Tag of the root to be added is as follows: " << root << endl;
	cout << endl << std::string(80, '-') << std::endl;


	if (save)
	{
		cout << "The root has been added successfully" << endl;
		cout << endl << std::string(80, '-') << std::endl;

		sPtr elem = store1.docElementReturn();
		cout << elem->toString();
	}
	else
	{
		cout << "Could not add root successfully as it contains root already" << endl;
		cout << endl << std::string(80, '-') << std::endl;

	}
	cout << endl;
}

//--------------<Creating and storing an XML file>----------------

void Display:: displayCreateXml(int counter)
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating the created XML";
	cout << endl << std::string(80, '/') << std::endl << endl;


	std::string s = std::to_string(counter);
	string fileName = "test" + s + ".xml";
	std::ofstream outfile(fileName);
	if (store1.docElementReturn() != nullptr){
		outfile << store1.docElementReturn()->toString() << std::endl;
		cout << "The file is present in the Current folder: " << fileName << endl;
	}
	outfile.close();
}

//--------------<display Move Constructors>----------------


void Display:: displayMoveConst()
{
	cout << endl << std::string(80, '/') << std::endl;
	cout << "Demonstrating Requirement 4";
	cout << endl << std::string(80, '/') << std::endl << endl;
	XmlDocument doc2 = std::move(store1);
	XmlDocument doc3(" ");
	doc3 = std::move(doc2);
	cout << endl << std::string(80, '-') << std::endl;


}
//--------------<Test Stub>----------------

#ifdef TEST_DISPLAY

void main()
{
	using sPtr = std::shared_ptr < AbstractXmlElement >;

	XmlDocument doc("LectureNote.xml"); Display d(doc);
	string parent = "LectureNote"; string child = "newChild"; string parent1 = "LectureNote"; string child1 = "newChild1";
	string root = "root"; std::string key = "dlsn"; std::string value = "sdksj"; string title = "title";	string tag = "reference"; string tag1 = "author"; string id = "Wintellect";
	doc.adding_Elements();												// Creation of the Abstract Syntax Tree
	std::vector<sPtr> a = doc.element(title).select();
	d.displayElement(a, title);										//display Element
	std::vector<sPtr> b = doc.elements(title).select();
	d.displayElements(b, title);									//display Elements
	std::vector<sPtr> c = doc.element(tag).children().select();
	d.displayChildren(c, tag, "");									//display Children
	std::vector<sPtr> save = doc.element(tag).descendents().select();
	d.displayDescendents(save, tag, "");										//display Descendents
	std::vector<sPtr> childsearch = doc.element(tag).children(tag1).select();
	d.displayChildren(childsearch, tag, tag1);
	std::vector<sPtr> dsearch = doc.element(tag).descendents(tag1).select();
	d.displayDescendents(dsearch, tag, tag1);
	std::vector<sPtr> ele = doc.findElementById(id).select();
	d.displayElement_ID(ele, id);												//display ElementById
	bool save2 = doc.addChildren_tagwise(parent, child);
	d.displayAddChildren(save2, parent, child);									//display AddChildren
	bool save21 = doc.addChildren_Idwise(parent1, child1);
	d.displayAddChildren_ID(save21, parent1, child1);							//display AddchilbyId
	bool save3 = doc.removeChildren_tagwise(parent, child);
	d.displayRemoveChildren(save3, parent, child);								//display RemoveChildren
	bool save31 = doc.removeChildren_Idwise(parent1, child1);
	d.displayRemoveChildren_ID(save31, parent1, child1);						//displayRemoveChildrenById
	bool save4 = doc.addRoot_foremptytree(root);
	d.displayAddRoot(save4, root);												//displayAddRoot
	std::vector<std::pair<std::string, std::string>> save5 = doc.fetchAttributes_tagwise(parent);
	d.displayFetchedAttributes(save5, parent);
	bool save6 = doc.element(parent).addAttribute_tagwise(key, value);
	d.displayAddAttribute(save6, parent, key, value);							//display AddAttribute
	bool save7 = doc.element(parent).removeAttribute_tagwise(value);
	d.displayRemoveAttribute(save7, parent, value);								//displayRemoveAttribute
	d.displayCreateXml(1);												//displayCreateXml
	d.displayMoveConst();

}

#endif
