#ifndef DISPLAY_H
#define DISPLAY_H
/////////////////////////////////////////////////////////////////////////////
// Display.h - Responsible for displaying the results of the XML Document      //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2013                             //
//  Platform:    MAC OSX,Core i5, Windows 7                               //
// Application: Spring, 2015 : XML Document Model                          //
// Author:      Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu                          //
/////////////////////////////////////////////////////////////////////////////

/*
* Module Operations :
*== == == == == == == == ==
This  file contains the Display class for displaying all the requirement of Project 2

Public Interface:
=================
public:
Display(XmlDocument& ds);
using sPtr = std::shared_ptr < AbstractXmlElement > ;
void displayElement(std::vector<sPtr> e, std::string title);
void displayElements(std::vector<sPtr> e, std::string title);
void displayChildren(std::vector<sPtr> e, std::string tag, std::string tag1);
void displayDescendents(std::vector<sPtr> e, std::string tag, std::string tag1);
void displayElement_ID(std::vector<sPtr> e, std::string id);
void displayAddChildren(bool check, std::string parent,std:: string child);
void displayAddChildren_ID(bool check, std::string parent, std::string child);
void displayRemoveChildren(bool check, std::string parent, std::string child);
void displayRemoveChildren_ID(bool check, std::string parent, std::string child);
void displayAddRoot(bool save, std::string root);
void displayFetchedAttributes(std::vector<std::pair<std::string, std::string>> attr, std::string parent);
void displayAddAttribute(bool check, std::string parent,std:: string key,std::string value);
void displayRemoveAttribute(bool check, std::string parent, std::string value);
void displayCreateXml(int counter);
void displayMoveConst();

Required Files:
===============
Tokenizer.h, Display.cpp, XmlDocument.h, XmlElement.h, xmlElementParts.h

Build Command:
==============
cl /EHa /TEST_DISPLAY Display.cpp


Maintenance History:
====================
ver 1.0 : 23 Mar 15
- first release
*/

#include <iostream>
#include<vector>
#include "../XmlDocument/XmlDocument.h"
#include "../XmlElement/XmlElement.h"
using namespace std;

///////////////////////////////////////////////
//used to display the output to the user

namespace XmlProcessing
{
	class Display{
	public:
		Display(XmlDocument& ds);
		using sPtr = std::shared_ptr < AbstractXmlElement > ;
		void displayElement(std::vector<sPtr> e, std::string title);
		void displayElements(std::vector<sPtr> e, std::string title);
		void displayChildren(std::vector<sPtr> e, std::string tag, std::string tag1);
		void displayDescendents(std::vector<sPtr> e, std::string tag, std::string tag1);
		void displayElement_ID(std::vector<sPtr> e, std::string id);
		void displayAddChildren(bool check, std::string parent,std:: string child);
		void displayAddChildren_ID(bool check, std::string parent, std::string child);
		void displayRemoveChildren(bool check, std::string parent, std::string child);
		void displayRemoveChildren_ID(bool check, std::string parent, std::string child);
		void displayAddRoot(bool save, std::string root);
		void displayFetchedAttributes(std::vector<std::pair<std::string, std::string>> attr, std::string parent);
		void displayAddAttribute(bool check, std::string parent,std:: string key,std::string value);
		void displayRemoveAttribute(bool check, std::string parent, std::string value);
		void displayCreateXml(int counter);
		void displayMoveConst();
	private:
		XmlDocument& store1;
	};
}

#endif