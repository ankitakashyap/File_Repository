/////////////////////////////////////////////////////////////////////////////
// Executive.cpp - Handles the entire operating of the XML Document Model  //
// ver 1.0                                                                 //
// Language:    Visual C++ 11, Visual Studio 2013            //                       
// Platform:    MAC OSX,Core i5, Windows 7                          //
// Application: Spring, 2015 : XML Document Model                          //
// Author:      Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu                          //
/////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <locale>  
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <cctype>      
#include <functional>
#include <Windows.h>
#include "Executive.h"
#include "../XmlDocument/XmlDocument.h"
#include "../Display/Display.h"


using namespace XmlProcessing;

void testchildrenbyId(XmlDocument& doc, Display& d)
{
	string parent2 = "CSE681";
	string child1 = "newChild";
	bool save21 = doc.addChildren_Idwise(parent2, child1);
	d.displayAddChildren_ID(save21, parent2, child1);
}
void testdescendentbytag(XmlDocument& doc, Display& d)
{
	string tag = "reference";
	string tag1 = "author";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> dsearch = doc.element(tag).descendents(tag1).select();
	d.displayDescendents(dsearch, tag, tag1);
}

void testelement(XmlDocument& doc, Display& d)
{
	string title = "title";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> a = doc.element(title).select();
	d.displayElement(a, title);
}

void testAddChildren(XmlDocument& doc, Display& d)
{
	string parent = "LectureNote";
	string child = "newChild";
	bool save2 = doc.addChildren_tagwise(parent, child);
	d.displayAddChildren(save2, parent, child);
}

void testaddroot(XmlDocument& doc, Display& d)
{
	string root = "root";
	bool save4 = doc.addRoot_foremptytree(root);
	d.displayAddRoot(save4, root);
}
void testelements(XmlDocument& doc, Display& d)
{
	string title = "title";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> a = doc.elements(title).select();
	d.displayElement(a, title);
}

void testAttributefetch(XmlDocument& doc, Display& d)
{
	string parent = "LectureNote";
	std::vector<std::pair<std::string, std::string>> save5 = doc.fetchAttributes_tagwise(parent);
	d.displayFetchedAttributes(save5, parent);
}

void testelementbyId(XmlDocument& doc, Display& d)
{
	string id = "Wintellect";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> ele = doc.findElementById(id).select();
	d.displayElement_ID(ele, id);
}
void testchildren(XmlDocument& doc, Display& d)
{
	string tag = "reference";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> c = doc.element(tag).children().select();
	d.displayChildren(c, tag, "");
}

void test_removechildrenbyId(XmlDocument& doc, Display& d)
{
	string parent2 = "CSE681";
	string child1 = "newChild";
	bool save31 = doc.removeChildren_Idwise(parent2, child1);
	d.displayRemoveChildren_ID(save31, parent2, child1);
}
void testdescendents(XmlDocument& doc, Display& d)
{
	string tag = "reference";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> save = doc.element(tag).descendents().select();
	d.displayDescendents(save, tag, "");
}
void testchildrenbytag(XmlDocument& doc, Display& d)
{
	string tag = "reference";
	string tag1 = "author";
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	std::vector<sPtr> childsearch = doc.element(tag).children(tag1).select();
	d.displayChildren(childsearch, tag, tag1);
}

void testAddAttribute(XmlDocument& doc, Display& d)
{
	string parent = "LectureNote";
	std::string key = "dlsn";
	std::string value = "sdksj";
	bool save6 = doc.element(parent).addAttribute_tagwise(key, value);
	d.displayAddAttribute(save6, parent, key, value);
}

void test_removechildren(XmlDocument& doc, Display& d)
{
	string parent = "LectureNote";
	string child = "newChild";
	bool save3 = doc.removeChildren_tagwise(parent, child);
	d.displayRemoveChildren(save3, parent, child);
}

void testRemoveAttribute(XmlDocument& doc, Display& d)
{
	string parent = "LectureNote";
	std::string value = "sdksj";
	bool save7 = doc.element(parent).removeAttribute_tagwise(value);
	d.displayRemoveAttribute(save7, parent, value);
}


//--------------<the program execution and flow starts from this point>----------------

#ifdef TEST_EXECUTIVE
int main(int argc, char *  argv[])
{
	using sPtr = std::shared_ptr < AbstractXmlElement >;
	if (argc < 2){
		std::cout << "\n  please enter name of file to process on command line\n\n";
		return 1;
	}
	for (int i = 1; i < argc; ++i){
		std::ifstream f(argv[i]);
		if (!(f.is_open())){
			cout << endl << "Please Provide correct filename" << endl << endl;
			break;
		}

		XmlDocument doc_ele(argv[i]); Display disp(doc_ele);
		doc_ele.adding_Elements();

		testelement(doc_ele, disp); 
		testelements(doc_ele, disp);								
		testchildren(doc_ele, disp);
		testdescendents(doc_ele, disp);
		testchildrenbytag(doc_ele, disp);
		testdescendentbytag(doc_ele, disp);
		testelementbyId(doc_ele, disp);
		testAddChildren(doc_ele, disp);
		testchildrenbyId(doc_ele, disp);
		test_removechildren(doc_ele, disp);				
		test_removechildrenbyId(doc_ele, disp);
		testaddroot(doc_ele, disp);
		testAttributefetch(doc_ele, disp);
		testAddAttribute(doc_ele, disp);				
		testRemoveAttribute(doc_ele, disp);
		disp.displayCreateXml(i);    
		disp.displayMoveConst();
	}
	return 0;
}
#endif