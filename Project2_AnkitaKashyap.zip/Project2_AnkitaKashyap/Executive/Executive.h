#ifndef EXECUTIVE_H
#define EXECUTIVE_H
/////////////////////////////////////////////////////////////////////////////
// Executive.h - Handles the entire operating of the XML Document Model    //
// ver 1.0                                                                 //
// Language:    Visual C++, Visual Studio 2013                             //
// Platform:    MAC OSX,Core i5, Windows 7                          //
// Application: Spring, 2015 : XML Document Model                          //
// Author:  Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu                                 //
/////////////////////////////////////////////////////////////////////////////

/*
* Module Operations :
*== == == == == == == == ==
* This module is the main module from which the execution takes place

Public Interface:
=================
public:
No methods defined

Required Files:
===============
Tokenizer.h, Display.h, Executive.cpp, XmlDocument.h, XmlElement.h, xmlElementParts.h

Build Command:
==============
devenv XmlDocument.sln /rebuild debug

Maintenance History:
====================
ver 1.0 : 23 Mar 15
- first release
*/

#include <iostream>
#include<vector>
#include<regex>

////////////////////////////////////////////////////////////
// starting class of the application, controls the flow

namespace XmlProcessing
{
	class  Executive
	{
	public:
	private:

	};
}
#endif
