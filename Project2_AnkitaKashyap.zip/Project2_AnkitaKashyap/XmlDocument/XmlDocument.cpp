///////////////////////////////////////////////////////////////////////////////////////////////////
// XmlDocument.cpp - a container of XmlElement nodes and functions    //
// Ver 1.3                                                       //
// Application: Spring 2015 : XML Document Model                 //
// Platform:    Dell XPS 2720, Win 8.1 Pro, Visual Studio 2013   //
// Author:      Jim Fawcett, CST 4-187, 443-3948                 //
//              jfawcett@twcny.rr.com							 //
//Modified By: Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu        				 //
/////////////////////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include "XmlDocument.h"

using namespace XmlProcessing;



//--------------<return vector of sPtrs from AST>----------------

std::vector<std::shared_ptr < AbstractXmlElement >> XmlDocument::select()
{
	return found_;
}

//--------------<Move constructor for XmlDocument>----------------

XmlDocument& XmlDocument:: operator=(XmlDocument&& other){
	if (this != &other){
		pDocElement_.reset();
		std::cout << "\n Move Assignment operator Called" << std::endl;
		pDocElement_ = other.pDocElement_;
		other.pDocElement_ = nullptr;
	}
	return *this;
}
//----------------<Checking for XML Declaration tag>-----------------------------------------

bool XmlDocument::xmldeclare_parse(std::string tokenString)
{
	sPtr de = makeXmlDeclarElement();
	int s = tokenString.find("=");
	if (s != -1)
		attributes_insertbytag(de, tokenString);
	pDocElement_->addChild(de);            // adding xml declaration as child to doc element in the AST
		return true;
}

//----------------<Checking for Comments tag>-----------------------------------
bool XmlDocument::comment(std::string tokenString, bool key1)
{
	int ce = tokenString.find("-");
	std::string strc;
	for (unsigned int i = ce + 3; i < tokenString.size(); i++)
	{
		strc.push_back(tokenString[i]);
		if (tokenString[i + 2] == '-')
			break;
	}
	sPtr comment = makeCommentElement(strc);
	pDocElement_->addChild(comment);           // if comment is present, then it is added as child to doc element
	return true;
}
//--------------<checking for tags and inserting elements in the Abstract Syntax Tree>----------------

void XmlDocument::adding_Elements()
{
	Toker toker(fileName);
	toker.setMode(Toker::xml);
	XmlParts parts(&toker);
	pDocElement_ = makeDocElement();
	std::string text;
	int ctr = 0;
	while (parts.get()){
		if (parts.length() <= 1 && ctr == 0)
			return;
		ctr++;
		bool key1 = false;
		std::string tokenString = parts.show();
		bool key2 = false;

		if (tokenString.find("? xml") != -1 && tokenString.find("? xml -") == -1)   // checking for xml declaration
		{
			key1 = xmldeclare_parse(tokenString);
		}
		int point1 = tokenString.find(" = ");
		if (tokenString.find("? xml -") != -1)                                            // checking for processing instructions
		{
			key1 = process_inst(point1, tokenString, key1);

		}
		int point2 = tokenString.find("!");
		if (point2 != -1){                                                                     //   checking for comments
			key1 = comment(tokenString, key1);
		}

		int point3 = tokenString.find("<"); int point4 = tokenString.find("< /"); int point5 = tokenString.find("/ >");

		if ((tokenString.find("? xml") == -1) && (point1 != -1 || point3 != -1 || point5 != -1) && (point2 == -1) && (tokenString.find("? xml -") == -1))
			key2 = tagged_elementparse(point1, point3, point4, point5, tokenString, key1);               //checking for tagged element

		if (!key1 && !key2)
		{
			text = tokenString;
			sPtr spt = element_stack.top();
			spt->addChild(makeTextElement(text));                 //adding child
		}
	}
}


//--------------<Checking for tagged elements and inserting in the Abstract Syntax Tree>----------------


bool XmlDocument::tagged_elementparse(int point1, int point3, int point4, int point5, std::string tokenString, bool key1)
{
	if ((point1 != -1 || point3 != -1 || point5 != -1) && (point4 == -1)){
	
		std::string insertion;

		unsigned int i = 4;
		while (i < tokenString.size())
		{
			if (tokenString[i] == ' ')
				break;
			insertion.push_back(tokenString[i]);
			i++;
		}
		sPtr tag_e = makeTaggedElement(insertion);
		if (point1 != -1)
			attributes_insertbytag(tag_e, tokenString);
		if (element_stack.empty())
			pDocElement_->addChild(tag_e);
		else{
			sPtr st = element_stack.top();
			st->addChild(tag_e);
		}
		element_stack.push(tag_e);
		key1 = true;
	}
	if (point4 != -1)
	{
		element_stack.pop();
		key1 = true;
	}
	return key1;
}

//--------------<Checking for Processing instruction tags  and inserting in the Abstract Syntax Tree>----------------

bool XmlDocument::process_inst(int s2, std::string tokenString, bool key1)
{
	int et;
	std::string insertion;
	unsigned int i = 6;
	while (i < tokenString.size())
	{
		if (tokenString[i] == '=' || tokenString[i] == '?')
			break;
		if (tokenString[i - 1] == ' ')
			et = i - 1;
		insertion.push_back(tokenString[i]);
		i++;
	}

	std::string str_proc = insertion.substr(0, (et - 6));
	insertion.clear();

	for (auto a1 : str_proc)
	{
		if (a1 != ' ')
			insertion.push_back(a1);
	}
	sPtr p1 = makeProcInstrElement(insertion);
	if (s2 != -1)
		attributes_insertbytag(p1, tokenString);
	pDocElement_->addChild(p1);            //adding the processing instruction as child to the doc element in the Abstract Syntax Tree
	key1 = true;
	
	return key1;
}

//--------------<Depth first search over AST using stack>----------------

void XmlDocument::DFS_stack(sPtr pNode, std::string tag)
{
	std::stack<sPtr> tempStack;
	tempStack.push(pNode);
	while (tempStack.size() > 0)
	{
		sPtr pCurrentNode = tempStack.top();
		tempStack.pop();
		if (pCurrentNode->value() == tag)
		{
			found_.push_back(pNode);

		}
		else if (tag == "" && dynamic_cast<TextElement*>(pNode.get()) == nullptr)
		{
			found_.push_back(pNode);
		}
		size_t numChildren = pCurrentNode->children().size();
		for (size_t i = 0; i < numChildren; ++i)
			tempStack.push(pCurrentNode->children()[numChildren - i - 1]);

	}
	
}

//--------------<Depth first search over Abstract Syntax Tree using Id >----------------

void XmlDocument::DFS_Id(sPtr pNode, std::string id)
{
	if (dynamic_cast<TaggedElement*>(pNode.get()) != nullptr || dynamic_cast<ProcInstrElement*>(pNode.get()) != nullptr || dynamic_cast<XmlDeclarElement*>(pNode.get()) != nullptr)
	{
		std::vector<std::pair<std::string, std::string>> att = pNode->returnAttrib();
		for (std::vector<std::pair<std::string, std::string>>::iterator iter = att.begin(); iter != att.end(); ++iter)
		{
			if ((iter->second) == id)
			{
				found_.push_back(pNode);
				for (auto pChild : pNode->children())
				{
					DFS_stack(pChild, id);
				}
			}
		}

	}

	for (auto pChild : pNode->children())
	{
		DFS_stack(pChild, id);
	}
}

//--------------<Add children in Abstract Syntax Tree based on tag>----------------


bool XmlDocument::addChildren_tagwise(const std::string& parent, const std::string& child)
{

	std::vector<std::shared_ptr < AbstractXmlElement >> root = element(parent).select();
	if (root.size() <= 0)
	{
		return false;
	}
	sPtr tag_e = makeTaggedElement(child);
	root[0]->addChild(tag_e);
	return true;
}

//--------------<Find element by tag from the AST>----------------

XmlDocument& XmlDocument::element(const std::string& tag)
{
	found_.clear();
	std::vector<sPtr> child_vector;
	if (pDocElement_ != nullptr){
		child_vector = pDocElement_->children();
		for (std::vector<sPtr>::iterator it = child_vector.begin(); it != child_vector.end(); ++it) {
			DFS_stack(*it, tag);
		}

			if (found_.size() > 0)
			{
				found_.erase(found_.begin() + 1, found_.begin() + found_.size());
			}
	}
	return *this;
}

//--------------<Add root to an empty tree>----------------

bool XmlDocument::addRoot_foremptytree(std::string root)
{
	auto save = element("").select();
	DocElement* a = dynamic_cast<DocElement*> (pDocElement_.get());
	if (a != NULL){
		if ((a->hasXmlRoot()))
		{
			return false;
		}
		else
		{
			sPtr tag_e = makeTaggedElement(root);
			pDocElement_->addChild(tag_e);
			return true;
		}
	}
	else
	{
		pDocElement_ = makeDocElement();
		sPtr tag_e = makeTaggedElement(root);
		pDocElement_->addChild(tag_e);
		return true;
	}
}

//--------------<Elements are found from the Abstract Syntax Tree based on id>----------------

XmlDocument& XmlDocument::findElementById(const std::string& id)
{
	found_.clear();
	std::vector<sPtr> child;
	if (pDocElement_ != nullptr){
		child = pDocElement_->children();
		for (std::vector<sPtr>::iterator it = child.begin(); it != child.end(); ++it) {
			DFS_stack(*it, "");
		}
		child = found_;
		found_.clear();
		for (std::vector<sPtr>::iterator it = child.begin(); it != child.end(); ++it)
		{
			if (dynamic_cast<TaggedElement*>((*it).get()) != nullptr || dynamic_cast<ProcInstrElement*>((*it).get()) != nullptr || dynamic_cast<XmlDeclarElement*>((*it).get()) != nullptr)
			{
				std::vector<std::pair<std::string, std::string>> att = (*it)->returnAttrib();
				for (std::vector<std::pair<std::string, std::string>>::iterator itr = att.begin(); itr != att.end(); ++itr)
				{
					if ((itr->second) == id)
					{
						found_.push_back((*it));
					}
				}
			}
		}
	}
	return *this;
}



//--------------<Attributes are inserted  into the tags of the Abstract Syntax Tree>----------------

void XmlDocument::attributes_insertbytag(std::shared_ptr < AbstractXmlElement >& element, std::string tokenString)
{
	std::string attribute_key;
	std::string t_att;
	std::string value;

	for (unsigned int ins = 0; ins < tokenString.size(); ins++)
	{
		if (tokenString[ins] == '=')
		{
			attribute_key.clear();
			value.clear();
			t_att.clear();
			for (unsigned int i = ins - 2; i>0; i--)
			{
				t_att.push_back(tokenString[i]);
				if (tokenString[i] == ' ')
					break;
			}
			for (unsigned int j = t_att.size() - 2; j >= 0; j--)
			{
				attribute_key.push_back(t_att[j]);
				if (j == 0)
					break;
			}
			for (unsigned int k = ins + 3; k<tokenString.size(); k++)
			{
				if (tokenString[k] == '\"' || tokenString[k] == '\'')
					break;
				value.push_back(tokenString[k]);
			}
			element->addAttrib(attribute_key, value);
		}
	}
}

//--------------<Remove children from the Abstract Syntax Tree using ID>----------------

bool XmlDocument::removeChildren_Idwise(const std::string& parent, const std::string& child)
{
	bool check = false;
	std::vector<std::shared_ptr < AbstractXmlElement >> root = findElementById(parent).select();
	if (root.size()>0)
	{
		std::vector<std::shared_ptr < AbstractXmlElement >> children = root[0]->children();

		for (auto pChild : children)
		{
			if (pChild->value() == child)
			{
				root[0]->removeChild(pChild);
				return true;
			}
		}
		}
	return false;
}


//--------------<Finding descendents in Abstract Syntax Tree by tag>----------------

XmlDocument& XmlDocument::descendents(const std::string& tag)
{
	std::vector<sPtr> child_vector= found_;
	
	if (found_.size() <= 0)
		return *this;
	sPtr apt = found_[0];
	found_.clear();
	child_vector = apt->children();
	
	for (std::vector<sPtr>::iterator iter = child_vector.begin(); iter != child_vector.end(); ++iter) {
		DFS_stack(*iter, tag);
	}
	return *this;
}



//--------------<add children in Abstract Syntax Tree based on the id>----------------

bool XmlDocument::addChildren_Idwise(const std::string& parent, const std::string& child)
{
	
	std::vector<std::shared_ptr < AbstractXmlElement >> root = findElementById(parent).select();
	sPtr tag_e = makeTaggedElement(child);
	if (root.size()>0)
	{
		root[0]->addChild(tag_e);
		return true;
	}
	return false;
}




//--------------<remove children in Abstract Syntax Tree based on tag>----------------

bool XmlDocument::removeChildren_tagwise(const std::string& parent, const std::string& child)
{
	bool tokenString = false;
	std::vector<std::shared_ptr < AbstractXmlElement >> root = element(parent).select();
	if (root.size() <= 0)
		return false;
	std::vector<std::shared_ptr < AbstractXmlElement >> children1 = root[0]->children();
	for (unsigned int i = 0; i < children1.size(); i++)
	{
		if (children1[i]->value() == child)
		{
			root[0]->removeChild(children1[i]);
			tokenString = true;
			break;
		}
	}
	return true;
}

//--------------<Obtain the attributes from the Abstract Syntax Tree based on the tag acquired>----------------

std::vector<std::pair<std::string, std::string>> XmlDocument::fetchAttributes_tagwise(std::string tag)
{
	std::vector<std::shared_ptr < AbstractXmlElement >> root = element(tag).select();
	std::vector<std::pair<std::string, std::string>> attr;
	if (root.size()>0)
	{
		attr = root[0]->returnAttrib();
	}
	return attr;
}


//--------------<Removes the attributes from Abstract Syntax Tree tag by tag>----------------

bool XmlDocument::removeAttribute_tagwise(const std::string& name)
{
	std::vector<sPtr> child_vector;
	child_vector = found_;
	if (found_.size() <= 0)
		return false;
	//sPtr apt = found_[0];
	bool tokenString = false;
	for (auto pElement : child_vector)
	{
		if (dynamic_cast<TaggedElement*>(pElement.get()) != nullptr || dynamic_cast<ProcInstrElement*>(pElement.get()) != nullptr || dynamic_cast<XmlDeclarElement*>(pElement.get()) != nullptr)
		{
			std :: vector<std::pair<std::string,std::string>> pd = pElement->returnAttrib();
			for (auto save : pd)
			{
				if (save.second == name)
				{
					tokenString = pElement->removeAttrib(name);
					tokenString = true;
					return tokenString;
				}
			}
		}
	}
	return tokenString;
}

//--------------<Find elements by tag from the AST>----------------

XmlDocument& XmlDocument::elements(const std::string& tag)
{
	found_.clear();
	std::vector<sPtr> child;
	if (pDocElement_ != nullptr)
	{
		child = pDocElement_->children();
		for (std::vector<sPtr>::iterator it = child.begin(); it != child.end(); ++it)
		{
			DFS_stack(*it, tag);
		}
	}
	return *this;
}
//--------------<add atributes from the Abstract Syntax Tree based on the tag>----------------

bool XmlDocument::addAttribute_tagwise(const std::string& name, const std::string& value)
{
	std::vector<sPtr> child_vector = found_;
	//child = found_;
	if (found_.size() <= 0)
		return false;
	sPtr apt = found_[0];
	for (auto pElement : child_vector)
	{
		if (dynamic_cast<TaggedElement*>(apt.get()) != nullptr || dynamic_cast<ProcInstrElement*>(apt.get()) != nullptr || dynamic_cast<XmlDeclarElement*>(apt.get()) != nullptr)
		{
			pElement->addAttrib(name, value);
			return true;
		}
	}
	return false;
}

//--------------<Finding children in Abstract Syntax Tree by tag>----------------

XmlDocument& XmlDocument::children(const std::string& tag)
{
	std::vector<sPtr> child_vector;
	child_vector = found_;
	if (found_.size() <= 0)
	{
		return *this;
	}
	sPtr apt = found_[0];
	found_.clear();
	child_vector = apt->children();
	for (unsigned int i = 0; i < child_vector.size(); i++)
	{
		if (child_vector[i]->value() == tag || tag == "")
		{
			if (dynamic_cast<TextElement*>(child_vector[i].get()) == nullptr)
				found_.push_back(child_vector[i]);
		}
	}
	return *this;
}


#ifdef TEST_XMLDOCUMENT

int main()
{
  title("Testing XmlDocument class");
  XmlDocument doc("LectureNote.xml");
  using sPtr = std::shared_ptr < AbstractXmlElement >;
  std::cout << "\n\n";
  doc.adding_Elements();
  auto save= doc.element("reference").descendents().select();
  auto savee = doc.element("reference").children().select();
  auto ele = doc.findElementById("Wintellect").select();
  auto save1 = doc.elements("title").select();
  auto save2 = doc.addChildren_tagwise("LectureNote", "newChild");
  auto save21 = doc.addChildren_Idwise("CSE681", "newChild");
  auto save3 = doc.removeChildren_tagwise("LectureNote", "newChild");
  auto save31 = doc.removeChildren_Idwise("CSE681", "newChild");
  auto save4 = doc.addRoot_foremptytree("root");
  auto save5 = doc.fetchAttributes_tagwise("LectureNote");
  auto save6 = doc.element("LectureNote").addAttribute_tagwise("dlsn","sdksj");
  auto save7 = doc.element("LectureNote").removeAttribute_tagwise("dlsn");
  std::cout <<std::endl<< doc.docElementReturn()->toString()<<std::endl;
  std::ofstream outfile("test.xml");
  outfile << doc.docElementReturn()->toString() << std::endl; 
  outfile.close();
  std::cout << std::endl<<"The file is present in the Executive folder with name: test.xml" << std::endl;

  std::cout << "\nDemonstrating move constructor" << std::endl;
  XmlDocument doc2 = std::move(doc);
  XmlDocument doc3(" ");
  doc3 = std::move(doc2);
  std::cout << "\n\n";
}
#endif
