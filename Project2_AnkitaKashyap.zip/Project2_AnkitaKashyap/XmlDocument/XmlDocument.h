#ifndef XMLDOCUMENT_H
#define XMLDOCUMENT_H
///////////////////////////////////////////////////////////////////
// XmlDocument.h - a container of XmlElement nodes               //
// Ver 1.3                                                       //
// Application: Spring, 2015 : XML Document Model                //
// Platform:    Dell XPS 2720, Win 8.1 Pro, Visual Studio 2013   //
// Author:      Jim Fawcett, CST 4-187, 443-3948                 //
//              jfawcett@twcny.rr.com							 //
//Modified By: Ankita Kashyap, Syracuse University                      //
//              (315) 436-7059, ankashya@syr.edu        			 //
///////////////////////////////////////////////////////////////////
/*
* Package Operations:
* -------------------
* This package is intended to help students in CSE687 - Object Oriented Design
* get started with Project #2 - XML Document Model.  It uses C++11 constructs,
* most noteably std::shared_ptr.  The XML Document Model is essentially
* a program-friendly wrapper around an Abstract Syntax Tree (AST) used to
* contain the results of parsing XML markup.
*
* Abstract Syntax Trees, defined in this package, are unordered trees with 
* two types of nodes:
*   Terminal nodes     - nodes with no children
*   Non-Terminal nodes - nodes which may have a finite number of children
* They are often used to contain the results of parsing some language.
*
* The elements defined in the companion package, XmlElement, will be used in
* the AST defined in this package.  They are:
*   AbstractXmlElement - base for all the XML Element types
*   DocElement         - XML element with children designed to hold prologue, Xml root, and epilogue
*   TaggedElement      - XML element with tag, attributes, child elements
*   TextElement        - XML element with only text, no markup
*   CommentElement     - XML element with comment markup and text
*   ProcInstrElement   - XML element with markup and attributes but no children
*   XmlDeclarElement   - XML declaration element with attributes
*
* Required Files:
* ---------------
*   - XmlDocument.h, XmlDocument.cpp, 
	  Tokenizer.h, Tokenizer.cpp
	  xmlElementParts.h, xmlElementParts.cpp
*     XmlElement.h, XmlElement.cpp

Public Interface:
=================

using sPtr = std::shared_ptr < AbstractXmlElement > ;

enum sourceType { string, filename };

XmlDocument(const std::string& src)                                                //constructor
{
fileName = src;
}

XmlDocument(XmlDocument& other) = delete;
XmlDocument(XmlDocument&& other) : pDocElement_(other.pDocElement_){other.pDocElement_ = nullptr;
std::cout << " Move Constructor Called";}

XmlDocument& operator=(XmlDocument&& other);
XmlDocument& element(const std::string& tag);           // found_[0] contains first element (DFS order) with tag
XmlDocument& elements(const std::string& tag);          // found_ contains all elements with tag
XmlDocument& children(const std::string& tag = "");     // found_ contains sPtrs to children of prior found_[0]
XmlDocument& descendents(const std::string& tag = "");  // found_ contains sPtrs to descendents of prior found_[0]
std::vector<sPtr> select();                            // return reference to found_.  Use std::move(found_) to clear found_
bool addAttribute_tagwise(const std::string& name, const std::string& value);
XmlDocument& findElementById(const std::string& id);
bool removeAttribute_tagwise(const std::string& name);
void adding_Elements();                                                // for constructing the AST
bool addChildren_tagwise(const std:: string& parent, const std:: string& child);
bool addChildren_Idwise(const std::string& parent, const std::string& child);
bool removeChildren_tagwise(const std::string& parent, const std::string& child);
bool removeChildren_Idwise(const std::string& parent, const std::string& child);
void createDocElement(sPtr docElemnt){ pDocElement_ = docElemnt; }
sPtr docElementReturn(){ return pDocElement_; }
void DFS_stack(sPtr pNode, std::string tag);
void DFS_Id(sPtr pNode, std::string id);
void attributes_insertbytag(std::shared_ptr < AbstractXmlElement >& element, std::string check);
bool addRoot_foremptytree(std::string root);
std::vector<std::pair<std::string, std::string>> fetchAttributes_tagwise(std::string tag);
bool process_inst( int point1,  std::string tokenString, bool key1);
bool tagged_elementparse( int point1,  int point3, int point4, int point5,  std::string tokenString, bool key1);
bool xmldeclare_parse(std::string tokenString);
bool comment(std::string tokenString, bool key1);
* Build Process:
* --------------
cl /EHa /TEST_XMLDOCUMENT XmlDocument.cpp
*
* Maintenance History:
* --------------------
* ver 1.3 : 23 Mar 15
* added required functionalities to the methods, created test stubs
* ver 1.2 : 21 Feb 15
* - modified these comments and added functionality
* ver 1.1 : 14 Feb 15
* - minor changes to comments, method arguments
* Ver 1.0 : 11 Feb 15
* - first release
*/

#include <memory>
#include <string>
#include <stack>
#include "../XmlElement/XmlElement.h"
#include "../XmlElementParts/Tokenizer.h"
#include "../XmlElementParts/xmlElementParts.h"

///////////////////////////////////////////////
//For creation of Abstract Syntax Tree and perform desired queries and operations on it


namespace XmlProcessing
{
  class XmlDocument
  {
  public:
    using sPtr = std::shared_ptr < AbstractXmlElement > ;

    enum sourceType { string, filename };

	XmlDocument(const std::string& src)                                                //constructor 
	{
		fileName = src;
	}
	
	XmlDocument(XmlDocument& other) = delete;
	XmlDocument(XmlDocument&& other) : pDocElement_(other.pDocElement_){other.pDocElement_ = nullptr;
		std::cout << " Move Constructor Called";}

	XmlDocument& operator=(XmlDocument&& other);
    XmlDocument& element(const std::string& tag);           // found_[0] contains first element (DFS order) with tag
    XmlDocument& elements(const std::string& tag);          // found_ contains all elements with tag
    XmlDocument& children(const std::string& tag = "");     // found_ contains sPtrs to children of prior found_[0] 
    XmlDocument& descendents(const std::string& tag = "");  // found_ contains sPtrs to descendents of prior found_[0]
    std::vector<sPtr> select();                            // return reference to found_.  Use std::move(found_) to clear found_
	bool addAttribute_tagwise(const std::string& name, const std::string& value);
	XmlDocument& findElementById(const std::string& id);
	bool removeAttribute_tagwise(const std::string& name);
	void adding_Elements();                                                // for constructing the AST
	bool addChildren_tagwise(const std:: string& parent, const std:: string& child);
	bool addChildren_Idwise(const std::string& parent, const std::string& child);
	bool removeChildren_tagwise(const std::string& parent, const std::string& child);
	bool removeChildren_Idwise(const std::string& parent, const std::string& child);
	void createDocElement(sPtr docElemnt){ pDocElement_ = docElemnt; }
	sPtr docElementReturn(){ return pDocElement_; }
	void DFS_stack(sPtr pNode, std::string tag);
	void DFS_Id(sPtr pNode, std::string id);
	void attributes_insertbytag(std::shared_ptr < AbstractXmlElement >& element, std::string check);
	bool addRoot_foremptytree(std::string root);
	std::vector<std::pair<std::string, std::string>> fetchAttributes_tagwise(std::string tag);
	bool process_inst( int point1,  std::string tokenString, bool key1);
	bool tagged_elementparse( int point1,  int point3, int point4, int point5,  std::string tokenString, bool key1);
	bool xmldeclare_parse(std::string tokenString);
	bool comment(std::string tokenString, bool key1);

  private:
    sPtr pDocElement_;         // AST that holds procInstr, comments, XML root, and more comments
    std::vector<sPtr> found_;  // query results
	std::stack<sPtr> element_stack;
	std :: string fileName;
	
  };
}
#endif
